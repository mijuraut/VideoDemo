import React, { Component } from 'react';
import './App.css';

class FetchAngular extends Component {

    constructor(props) {
        super(props);
        console.log("App-komponentti: konstruktori (rakentaja).");

        this.state = {angularVideos: [] };
    }

    componentDidMount() {

        // console.log("App-komponentti: componentDidMount-metodissa.");
        // this.setState({ title: "väliaikainen otsikko"} );

        fetch('https://localhost:5001/toiminnot/angular')
            .then(response => response.json())
            .then(json => {
                console.log(json);

                console.log("App-komponentti: aloitetaan setState()-kutsu");
                this.setState({ angularVideos: json});
                console.log("App-kmponentti: setState()-metodia kutsuttu.");

            });

        console.log("App-komponentti: Fetch-kutsu tehty.");
    }

    render() {

        console.log("App-komponentti: render-metodissa.");

        let viesti = "";
        let taulukko= [];
        if (this.state.angularVideos.length > 0) {

            for (let i = 0; i < this.state.angularVideos.length; i++) {
                const element = this.state.angularVideos[i];
                taulukko.push(<tr>
                        <td>{element.link_text}</td>
                        <td><a href={element.url}>{element.description}</a></td>
                        <td>{element.length_minutes}</td>
                        <td>{element.date_added}</td>
                    </tr>);            
            }

        }
        else {
            viesti = "Ladataan tietoja videoDB-tietokannasta. Ei siis löytynä kun tuo angularVideos.length <= 0";
        }

        return (<div>
            <h2>Tietokantahaku</h2>
            <p>{viesti}</p>
            <table id = "t01">
                <tbody> 
                    {taulukko}
                </tbody>
            </table>
        </div>
        );
    }
}

export default FetchAngular;