import React, { Component } from 'react';
import App from './App';
import './App.css';
import FetchAngular from './FetchAngular';

class SuperComponent extends Component {
    render() {
        return (
            <div className="App">
            {/* <header className="App-header"></header> */}
            <h1>Videoita ohjelmoinnin opiskeluun</h1>
            {/* <App /> */}
            <FetchAngular />
            </div>
        );
    }
}

export default SuperComponent;